#include <iostream>
#include "fila.h"
#include "node.h"
#include <pthread.h>
#include "apresentacao.h"

using namespace std;

int main()
{
    apresentacao filas;
    int selecao=0;
    string anuncio;
    int loop=0;

    while(loop == 0){
        switch (selecao){
            case 0:
                cout << "1 - Incluir anuncio" << endl;
                cout << "2 - Carregar" << endl;
                cout << "3 - Remoner" << endl;
                cout << "4 - Iniciar apresentacao dos anuncios" << endl;
                cin >> selecao;
            break;
            case 1:
                cout << "Digite o anuncio" << endl;
                cin >> anuncio;
                filas.fila2.adicionaritem(anuncio);
                selecao=0;
            break;
            case 2:
                while(filas.fila2.head != 0){
                    filas.fila1.adicionaritem(filas.fila2.head->getVal());
                    filas.fila2.removeranuncio();
                }
                cout << "Anuncios adicionados a lista de reproducao" << endl;
                selecao=0;
            break;
            case 3:
                if(filas.fila1.head !=0){
                    filas.fila1.removeranuncio();
                    cout << "Anuncio removido" << endl;
                }
                else{
                    cout << "Nao existem anuncios" << endl;
                }
                selecao=0;
            break;
            case 4:


                selecao=0;
            default :
                selecao=0;
            break;
        }
    }
    return 0;
}

